import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, Subject } from 'rxjs';
import { ImageResult } from './models/txt2img';

@Injectable({
    providedIn: 'root',
})
export class SelectionService {
    private _selectedImage: ImageResult = { url: '', infotext: '' };
    private _selectedImageSubject: BehaviorSubject<ImageResult>;
    public imageSelected: Observable<ImageResult>;

    private _imageDeleted: Subject<ImageResult>;
    public imageDeleted: Observable<ImageResult>;

    private _prevImage: Subject<void>;
    private _nextImage: Subject<void>;
    public prevImageChanged: Observable<void>;
    public nextImageChanged: Observable<void>;


    constructor() {
        this._selectedImageSubject = new BehaviorSubject<ImageResult>(this._selectedImage);
        this.imageSelected = this._selectedImageSubject.asObservable();

        this._imageDeleted = new Subject<ImageResult>();
        this.imageDeleted = this._imageDeleted.asObservable();

        this._prevImage = new Subject<void>();
        this.prevImageChanged = this._prevImage.asObservable();
        this._nextImage = new Subject<void>();
        this.nextImageChanged = this._nextImage.asObservable();
    }

    public selectImage(image: ImageResult): void {
        this._selectedImage = image;
        this._selectedImageSubject.next(image);
    }

    public deleteImage(image: ImageResult): void {
        this._imageDeleted.next(image);
    }

    public nextImage(): void {
        this._nextImage.next()
    }

    public prevImage(): void {
        this._prevImage.next()
    }
}
