import { Component } from '@angular/core';
import { Progress, SDApiService } from './sdapi.service';
import { ImageResult, Txt2ImgInfo } from './models/txt2img';
import { MyApiService } from './myapi.service';
import { SelectionService } from './selection.service';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'myui';

  // prompt = '(best quality, masterpiece), 1girl, sexy, blond hair, red eyes'
  // negative = '(worst quality, low quality)'

  selectedIdx: number = -1
  images: ImageResult[] = []
  progress: Progress | undefined

  prompt_history: string[] = []
  load_prompt: string = ''

  constructor(private sdapi: SDApiService, private myapi: MyApiService, private selectionService: SelectionService) {
    this.setup().finally()
    this.loadImages()
    this.loadPrompts()
  }

  async setup() {
    this.selectionService.imageSelected.subscribe((image) => this.selectedIdx = this.images.indexOf(image))
    this.selectionService.imageDeleted.subscribe((image) => {
      this.images = this.images.filter(i => i.url != image.url)
      this.saveImages()
    })
    
    this.selectionService.prevImageChanged.subscribe(() => {
      const newIdx = this.selectedIdx - 1
      if(newIdx < 0) return
      const newImage = this.images[newIdx]
      this.selectionService.selectImage(newImage)
    })
    this.selectionService.nextImageChanged.subscribe(() => {
      const newIdx = this.selectedIdx + 1
      if(newIdx >= this.images.length) return
      const newImage = this.images[newIdx]
      this.selectionService.selectImage(newImage)
    })
  }

  getOptions() {
    this.sdapi.getOptions().subscribe((options) => {
      console.log('Current model is', options.sd_model_checkpoint)
    })
  }

  done = true
  sendPrompt() {
    if(!this.prompt_history.includes(this.sdapi.options.prompt)) {
      this.prompt_history.push(this.sdapi.options.prompt)
      localStorage.setItem('prompt_history', JSON.stringify(this.prompt_history))
    }
    this.done = false
    let id = setInterval(() => {
      this.sdapi.getProgress().subscribe((resp) => {
        this.progress = resp
      })
    }, 1000)
    this.sdapi.simpleTxt2Img().subscribe((resp) => {
      this.done = true
      clearInterval(id)
      resp.realinfo = JSON.parse(resp.info) as Txt2ImgInfo
      for (const [key, imageUrl] of resp.images.entries()) {
        const info = resp.realinfo.infotexts[key]
        this.images.push({ url: imageUrl, infotext: info })
      }
      this.saveImages()
      // this.imageInfo = resp.realinfo.infotexts[0]
    })
  }

  saveImages() {
    const imagesJson = JSON.stringify(this.images)
    localStorage.setItem('images', imagesJson)
  }

  loadImages() {
    const imagesJson = localStorage.getItem('images')
    if(!imagesJson) return
    const images = JSON.parse(imagesJson) as ImageResult[]
    this.images.length = 0
    for(const img of images) {
      this.images.push(img)
    }
  }

  loadPrompts() {
    const promptJson = localStorage.getItem('prompt_history')
    if(!promptJson) return
    const prompt_history = JSON.parse(promptJson) as string[]
    this.prompt_history.length = 0
    for(const prompt of prompt_history) {
      this.prompt_history.push(prompt)
    }
  }

  promptSelected(prompt: any) {
    this.load_prompt = prompt
  }
}
