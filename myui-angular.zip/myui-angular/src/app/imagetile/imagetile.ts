import { Component, Input, SimpleChanges } from "@angular/core";
import { SelectionService } from "../selection.service";
import { ImageResult } from "../models/txt2img";

@Component({
    selector: 'imagetile',
    templateUrl: './imagetile.html',
    styleUrls: ['./imagetile.scss']
})
export class ImageTileComponent {
    @Input() image: ImageResult | undefined

    size = 384

    constructor(private selectionService: SelectionService) {
        
    }

    ngOnChanges(changes: SimpleChanges) {
        // const ds = changes["imageUrl"]
        // if(ds.currentValue && ds.previousValue !== ds.currentValue) {
        //     this.imageUrl = `ds.currentValue`
        // }
    }

    selectImage(): void {
        if(this.image) this.selectionService.selectImage(this.image)
    }
}
