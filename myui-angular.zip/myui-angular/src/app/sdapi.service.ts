import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Options } from './models/options';
import { Txt2ImgRequest, Txt2ImgResponse } from './models/txt2img';
import { OptionsStore, default_options } from './options/options.component';

export interface Sampler {
  name: string;
  aliases: string[];
  options: any;
}

export interface Model {
  title: string
  model_name: string
  hash: string
  sha256: string
  filename: string
  config: string
}

export interface Upscaler {
  name: string
  model_name: string
  model_path: string
  model_url: string
  scale: number
}

export interface Progress {
  progress: number
  eta_relative: number
  state: State
  current_image: string
  textinfo: string
}

export interface State {
  skipped: boolean
  interrupted: boolean
  job: string
  job_count: number
  job_timestamp: string
  job_no: number
  sampling_step: number
  sampling_steps: number
}

@Injectable({
  providedIn: 'root'
})
export class SDApiService {

  options: OptionsStore

  constructor(private http: HttpClient) {
    this.options = default_options
  }

  setOptions(options: OptionsStore): void {
    this.options = options
  }

  simpleTxt2Img() {
    return this.txt2img(this.createTxt2ImgRequestWithOptions());
  }

  txt2img(payload: Txt2ImgRequest) {
    return this.http.post<Txt2ImgResponse>('/myapi/v1/txt2img', payload)
  }

  setModel(model: Model) {
    const payload = {
      sd_model_checkpoint: model.title
    }
    this.http
      .post<Options>('/sdapi/v1/options', payload)
      .subscribe((newOptions: Options) => {
        if (newOptions.sd_model_checkpoint !== model.title) throw new Error('Changing model resulted in options with different model: ' + model.title)
      })
  }

  getModels() {
    return this.http.get<Model[]>('/sdapi/v1/sd-models')
  }

  getSamplers() {
    return this.http.get<Sampler[]>('/sdapi/v1/samplers')
  }

  getUpscalers() {
    return this.http.get<Upscaler[]>('/sdapi/v1/upscalers')
  }

  getOptions() {
    return this.http.get<Options>('/sdapi/v1/options')
  }

  getProgress() {
    return this.http.get<Progress>('/sdapi/v1/progress')
  }

  private createTxt2ImgRequestWithOptions(): Txt2ImgRequest {
    const payload = {} as Txt2ImgRequest;
    payload.prompt = this.options.prompt;
    payload.negative_prompt = this.options.negative
    if (this.options.sampler) payload.sampler_name = this.options.sampler.name;

    payload.steps = this.options.steps;
    payload.save_images = false;
    payload.send_images = true;
    payload.height = this.options.image_height;
    payload.width = this.options.image_width;
    payload.cfg_scale = this.options.cfg_scale;
    payload.seed = -1
    payload.subseed = -1
    payload.subseed_strength = 0
    payload.restore_faces = false
    payload.tiling = false
    payload.styles = []
    payload.batch_size = this.options.image_count
    payload.n_iter = this.options.batches
    payload.enable_hr = !!this.options.upscaler
    if (this.options.upscaler) payload.hr_upscaler = this.options.upscaler.name
    payload.hr_scale = this.options.upscaler_scale
    payload.hr_resize_x = payload.width * this.options.upscaler_scale
    payload.hr_resize_y = payload.height * this.options.upscaler_scale
    

    payload.hr_second_pass_steps = this.options.upscaler_steps
    payload.denoising_strength = this.options.upscaler_denoise

    return payload
  }
}
