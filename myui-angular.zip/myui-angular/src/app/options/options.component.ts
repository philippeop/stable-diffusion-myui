import { Component, EventEmitter, Input, Output, SimpleChanges } from "@angular/core";
import { firstValueFrom } from 'rxjs';
import { Model, SDApiService, Sampler, Upscaler } from "../sdapi.service";
import { MyApiService } from "../myapi.service";

const PROMPT = 'prompt'
const NEGATIVE = 'negative'
const UPSCALER = 'upscaler'
const SAMPLER = 'sampler'
const STEPS = 'steps'

const options_per_model = true

export interface OptionsStore {
    [key: string]: any;
    prompt: string;
    negative: string;
    cfg_scale: number;
    upscaler: Upscaler | undefined;
    upscaler_scale: number;
    upscaler_steps: number;
    upscaler_denoise: number;
    sampler: Sampler | undefined;
    steps: number;
    // dont save model?
    image_width: number;
    image_height: number;
    batches: number;
    image_count: number;
}

export const default_options = {
    prompt: '',
    negative: '',
    cfg_scale: 7,
    upscaler: undefined,
    upscaler_scale: 1.5,
    upscaler_steps: 10,
    upscaler_denoise: 0.4,
    sampler: undefined,
    steps: 20,
    image_width: 640,
    image_height: 640,
    batches: 1,
    image_count: 1
} as OptionsStore
const option_keys = Object.keys(default_options)

@Component({
    selector: 'options',
    templateUrl: './options.component.html',
    styleUrls: ['./options.component.scss']
})
export class OptionsComponent {
    [key: string]: any;

    @Input() load_prompt: string = ''

    private _prompt: string = ''
    get prompt(): string { return this._prompt }
    set prompt(v: string) { this._prompt = v; this.save() }

    private _negative: string | undefined
    get negative(): string | undefined { return this._negative }
    set negative(v: string | undefined) { this._negative = v; this.save() }

    cfg_scale_title = `Classifier Free Guidance Scale - 
    how strongly the image should conform to prompt - 
    lower values produce more creative results`
    private _cfg_scale: number | undefined
    get cfg_scale(): number | undefined { return this._cfg_scale }
    set cfg_scale(v: number | undefined) { this._cfg_scale = v; this.save() }

    private _upscaler: Upscaler | undefined
    get upscaler(): Upscaler | undefined { return this._upscaler }
    set upscaler(v: Upscaler | undefined) { this._upscaler = v; this.save() }

    private _upscaler_scale: number | undefined
    get upscaler_scale(): number | undefined { return this._upscaler_scale }
    set upscaler_scale(v: number | undefined) { this._upscaler_scale = v; this.save() }

    private _upscaler_steps: number | undefined
    get upscaler_steps(): number | undefined { return this._upscaler_steps }
    set upscaler_steps(v: number | undefined) { this._upscaler_steps = v; this.save() }

    private _upscaler_denoise: number | undefined
    get upscaler_denoise(): number | undefined { return this._upscaler_denoise }
    set upscaler_denoise(v: number | undefined) { this._upscaler_denoise = v; this.save() }

    private _sampler: Sampler | undefined
    get sampler(): Sampler | undefined { return this._sampler }
    set sampler(v: Sampler | undefined) { this._sampler = v; this.save() }

    private _steps: number | undefined
    get steps(): number | undefined { return this._steps }
    set steps(v: number | undefined) { this._steps = v; this.save() }

    model: Model | undefined

    private _image_width: number | undefined
    get image_width(): number | undefined { return this._image_width }
    set image_width(v: number | undefined) { this._image_width = v; this.save() }

    private _image_height: number | undefined
    get image_height(): number | undefined { return this._image_height }
    set image_height(v: number | undefined) { this._image_height = v; this.save() }

    private _batches: number | undefined
    get batches(): number | undefined { return this._batches }
    set batches(v: number | undefined) { this._batches = v; this.save() }

    private _image_count: number | undefined
    get image_count(): number | undefined { return this._image_count }
    set image_count(v: number | undefined) { this._image_count = v; this.save() }

    samplers: Sampler[] = []
    upscalers: Upscaler[] = []
    models: Model[] = []

    constructor(private sdapi: SDApiService, private myapi: MyApiService) { }

    ngOnInit() {
        this.setup().finally(() => this.load())

    }
    async setup() {
        this.samplers = await firstValueFrom(this.sdapi.getSamplers())
        this.upscalers = await firstValueFrom(this.sdapi.getUpscalers())
        this.models = (await firstValueFrom(this.sdapi.getModels())).sort()
        const options = await firstValueFrom(this.sdapi.getOptions())
        this.model = this.models.find(m => m.title == options.sd_model_checkpoint)

    }

    ngOnChanges(changes: SimpleChanges) {
        const lp = changes["load_prompt"]
        if(lp && lp.currentValue && lp.currentValue !== lp.previousValue) {
            this.prompt = lp.currentValue
        }
    }

    modelChanged(event: any) {
        const title = event.target.value;
        this.model = this.models.find(s => s.title == title)
        if (this.model) this.sdapi.setModel(this.model)
    }

    samplerChanged(event: any) {
        const samplerName = event.target.value;
        this.sampler = this.samplers.find(s => s.name == samplerName)
    }

    upscalerChanged(event: any) {
        const name = event.target.value;
        this.upscaler = this.upscalers.find(s => s.name == name)
    }

    load(): void {
        let options = JSON.parse(JSON.stringify(default_options)) as OptionsStore
        try {
            const str = localStorage.getItem(this.key())
            if (str) options =  {...options,  ...(JSON.parse(str) as OptionsStore) }
        } catch (e) {
            console.error('failed to load options btw,', e)
        }
        for(const key of option_keys) {
            this[key] = options[key]
        }
    }

    save(): void {
        const options = {} as any
        for(const key of option_keys) {
            options[key] = this[key]
        }
        localStorage.setItem(this.key(), JSON.stringify(options))
        this.sdapi.setOptions(options)
        this.myapi.setOptions(options)
    }

    key() {
        return options_per_model ? this.model?.model_name + '_options' : 'options'
    }
}
