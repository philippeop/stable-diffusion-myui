import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Options } from './models/options';
import { OptionsStore, default_options } from './options/options.component';
import { Observable, EMPTY } from 'rxjs';
import { ImageResult } from './models/txt2img';


@Injectable({
    providedIn: 'root'
})
export class MyApiService {

    options: OptionsStore

    constructor(private http: HttpClient) {
        this.options = default_options
    }

    setOptions(options: OptionsStore): void {
        this.options = options
    }

    list() {
        return this.http.get<ImageResult[]>('/myapi/img')
    }

    delete(image: ImageResult) {
        var filename = image.url.replace(/^.*[\\\/]/, '')
        try {
            return this.http.delete('/myapi/img/' + filename)
        }
        catch (e) {
            return EMPTY
        }
    }
}
