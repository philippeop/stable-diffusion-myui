import { Component, Input, SimpleChanges } from "@angular/core";
import { SelectionService } from "../selection.service";
import { MyApiService } from "../myapi.service";
import { ImageResult } from "../models/txt2img";

@Component({
    selector: 'imagefocus',
    templateUrl: './imagefocus.html',
    styleUrls: ['./imagefocus.scss']
})
export class ImageFocusComponent {
    image: ImageResult | undefined = undefined

    constructor(private selectionService: SelectionService, private myapi: MyApiService) {
        selectionService.imageSelected.subscribe((image: ImageResult) => {
            if(!image.url) return
            this.image = image
        })
    }

    onClick(event: any) {
        const perc = event.clientX / window.innerWidth
        if(perc < 0.50) this.prev()
        else if (perc > 0.50) this.next()
    }

    delete(image: ImageResult): void {
        this.myapi.delete(image).subscribe(() => { 
            this.image = undefined
            this.selectionService.deleteImage(image)
        })
    }

    deselect() {
        this.image = undefined
    }

    prev() {
        this.selectionService.prevImage()
    }

    next() {
        this.selectionService.nextImage()
    }
}