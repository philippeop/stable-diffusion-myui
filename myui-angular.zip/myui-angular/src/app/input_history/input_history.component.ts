import { Component, EventEmitter, Input, Output, SimpleChanges } from "@angular/core";
import { SelectionService } from "../selection.service";

@Component({
    selector: 'input_history',
    templateUrl: './input_history.component.html',
    styleUrls: ['./input_history.component.scss']
})
export class InputHistoryComponent {
    @Input() values: string[]
    @Output() valueSelected = new EventEmitter<string>();

    constructor(private selectionService: SelectionService) {
        this.values = []
    }

    // ngOnChanges(changes: SimpleChanges) {
    //     // const ds = changes["imageUrl"]
    //     // if(ds.currentValue && ds.previousValue !== ds.currentValue) {
    //     //     this.imageUrl = `ds.currentValue`
    //     // }
    // }

    onValueClick(value: any): void {
        this.valueSelected.emit(value)
    }
}
